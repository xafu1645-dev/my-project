import os
import sqlite3
import secrets
from datetime import datetime
from functools import wraps
from flask import Flask, jsonify, request, render_template, g

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("QR_DATABASE_PATH", os.path.join(APP_DIR, "customers.db"))
ADMIN_KEY = os.environ.get("QR_ADMIN_KEY", "change-this-admin-key")

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["JSON_AS_ASCII"] = False

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("""
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ref TEXT NOT NULL UNIQUE,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      booking_name TEXT NOT NULL,
      quota_number TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('verified','pending','denied')),
      issue_date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
    """)
    count = db.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
    if count == 0:
        now = datetime.now().isoformat(timespec="seconds")
        demo = [
          ("QTA-8F29A1", "กิตติ", "ตัวอย่าง", "ใบจองโควต้าตัวอย่าง 001", "QT-2026-0018", "verified", "24/10/2569", now, now),
          ("QTA-3B71C4", "มาลี", "ทดสอบ", "ใบจองโควต้าตัวอย่าง 002", "QT-2026-0021", "pending", "24/10/2569", now, now),
          ("QTA-5D62E8", "สมชาย", "ตัวอย่าง", "ใบจองโควต้าตัวอย่าง 003", "QT-2026-0029", "denied", "24/10/2569", now, now),
        ]
        db.executemany("""INSERT INTO customers
          (ref,first_name,last_name,booking_name,quota_number,status,issue_date,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?,?)""", demo)
    db.commit()
    db.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        supplied = request.headers.get("X-Admin-Key", "")
        if not ADMIN_KEY or not secrets.compare_digest(supplied, ADMIN_KEY):
            return jsonify({"error": "ไม่มีสิทธิ์เข้าถึง กรุณาตรวจสอบรหัสผู้ดูแล"}), 401
        return fn(*args, **kwargs)
    return wrapper

def row_to_public(row):
    status_text = {"verified": "ยืนยันสิทธิ์แล้ว", "pending": "รอตรวจสอบ", "denied": "ไม่ผ่านการยืนยัน"}
    return {
      "ref": row["ref"],
      "first": row["first_name"],
      "last": row["last_name"],
      "booking": row["booking_name"],
      "quota": row["quota_number"],
      "status": row["status"],
      "statusText": status_text.get(row["status"], "รอตรวจสอบ"),
      "date": row["issue_date"]
    }

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/customers/lookup")
def lookup_customer():
    ref = (request.args.get("ref") or "").strip()
    if not ref or len(ref) > 120:
        return jsonify({"error": "กรุณาระบุเลขอ้างอิง"}), 400
    row = get_db().execute("SELECT * FROM customers WHERE ref = ?", (ref,)).fetchone()
    if row is None:
        return jsonify({"error": "ไม่พบรหัสอ้างอิงนี้ กรุณาติดต่อเจ้าหน้าที่"}), 404
    return jsonify(row_to_public(row))

@app.get("/api/demo")
def demo_list():
    rows = get_db().execute("SELECT ref, first_name, last_name, status FROM customers ORDER BY id LIMIT 20").fetchall()
    return jsonify([{
      "ref": r["ref"],
      "label": f'{r["first_name"]} {r["last_name"]} — {r["ref"]}',
      "status": r["status"]
    } for r in rows])

@app.get("/api/admin/customers")
@admin_required
def admin_list():
    rows = get_db().execute("SELECT * FROM customers ORDER BY id DESC").fetchall()
    return jsonify([row_to_public(r) for r in rows])

@app.post("/api/admin/customers")
@admin_required
def admin_create():
    data = request.get_json(silent=True) or {}
    required = ["first", "last", "booking", "quota", "status"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error": "กรุณากรอกข้อมูลให้ครบทุกช่อง"}), 400
    if data["status"] not in ("verified", "pending", "denied"):
        return jsonify({"error": "สถานะไม่ถูกต้อง"}), 400
    now = datetime.now().isoformat(timespec="seconds")
    ref = "QTA-" + secrets.token_hex(4).upper()
    while get_db().execute("SELECT 1 FROM customers WHERE ref=?", (ref,)).fetchone():
        ref = "QTA-" + secrets.token_hex(4).upper()
    issue_date = datetime.now().strftime("%d/%m/") + str(datetime.now().year + 543)
    db = get_db()
    db.execute("""INSERT INTO customers
      (ref,first_name,last_name,booking_name,quota_number,status,issue_date,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?)""",
      (ref, data["first"].strip(), data["last"].strip(), data["booking"].strip(),
       data["quota"].strip(), data["status"], issue_date, now, now))
    db.commit()
    row = db.execute("SELECT * FROM customers WHERE ref=?", (ref,)).fetchone()
    return jsonify(row_to_public(row)), 201

@app.patch("/api/admin/customers/<ref>")
@admin_required
def admin_update(ref):
    data = request.get_json(silent=True) or {}
    allowed = {"first": "first_name", "last": "last_name", "booking": "booking_name",
               "quota": "quota_number", "status": "status"}
    fields, values = [], []
    for key, column in allowed.items():
        if key in data:
            value = str(data[key]).strip()
            if not value:
                return jsonify({"error": f"ข้อมูล {key} ห้ามว่าง"}), 400
            if key == "status" and value not in ("verified", "pending", "denied"):
                return jsonify({"error": "สถานะไม่ถูกต้อง"}), 400
            fields.append(f"{column}=?")
            values.append(value)
    if not fields:
        return jsonify({"error": "ไม่มีข้อมูลสำหรับแก้ไข"}), 400
    fields.append("updated_at=?")
    values.extend([datetime.now().isoformat(timespec="seconds"), ref])
    db = get_db()
    cur = db.execute(f"UPDATE customers SET {','.join(fields)} WHERE ref=?", values)
    db.commit()
    if cur.rowcount == 0:
        return jsonify({"error": "ไม่พบลูกค้า"}), 404
    row = db.execute("SELECT * FROM customers WHERE ref=?", (ref,)).fetchone()
    return jsonify(row_to_public(row))

@app.delete("/api/admin/customers/<ref>")
@admin_required
def admin_delete(ref):
    db = get_db()
    cur = db.execute("DELETE FROM customers WHERE ref=?", (ref,))
    db.commit()
    if cur.rowcount == 0:
        return jsonify({"error": "ไม่พบลูกค้า"}), 404
    return jsonify({"ok": True, "message": "ลบข้อมูลแล้ว"})

@app.get("/health")
def health():
    return jsonify({"ok": True})

init_db()

if __name__ == "__main__":
    # For local testing only. For public deployment, use a production WSGI server and HTTPS.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
