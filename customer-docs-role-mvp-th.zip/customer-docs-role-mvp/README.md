# ระบบจัดเก็บเอกสารลูกค้าออนไลน์ — Role MVP

## แบบสิทธิ์
- ผู้ดูแล: เห็นและจัดการข้อมูลทั้งหมด และตั้งค่าสิทธิ์เจ้าหน้าที่
- เจ้าหน้าที่: เริ่มต้นไม่มีสิทธิ์ดู/เพิ่ม/แก้ไข/ลบ จนกว่าผู้ดูแลจะกำหนด
- ลูกค้าแต่ละรายมี `assigned_to` สำหรับมอบหมายให้เจ้าหน้าที่
- เอกสารสืบทอดสิทธิ์จากลูกค้าที่เชื่อมโยง
- RLS บังคับสิทธิ์ที่ฐานข้อมูล ไม่พึ่งการซ่อนปุ่มในหน้าเว็บอย่างเดียว
- พื้นที่เก็บไฟล์ตั้งเป็น private

## ตั้งค่า
1. สร้างโปรเจกต์ Supabase
2. รัน `supabase/schema.sql` ใน SQL Editor
3. สมัครบัญชีผ่าน Supabase Auth หรือหน้าเว็บ
4. ใน Authentication > Users คัดลอก UUID ของผู้ดูแลคนแรก แล้วรันคำสั่ง UPDATE ที่ท้าย `schema.sql`
5. ตั้งค่า Project URL และ publishable/anon key ใน `.env`
6. ก่อนใช้งานจริงต้องมีหน้าเว็บและ backend ที่ปลอดภัยสำหรับจัดการบัญชี Auth; ห้ามใช้ service_role key ใน browser

## ข้อควรทราบ
ไฟล์นี้เป็นโครงสร้างฐานข้อมูลและนโยบายความปลอดภัยเริ่มต้น ไม่ใช่ระบบ production ที่ผ่านการตรวจสอบแล้ว ต้องทดสอบ RLS และ Storage policies อย่างละเอียดก่อนใช้ข้อมูลจริง
ตัวอย่าง Storage policy จำกัดการอ่านไฟล์ให้บัญชีที่อัปโหลดเท่านั้น จึงต้องทำ secure signed-URL endpoint หรือปรับ storage policy อย่างปลอดภัยเพื่อแชร์ไฟล์ระหว่างเจ้าหน้าที่ที่ได้รับมอบหมาย
ควรเพิ่ม MFA, audit logging ที่บันทึกจาก trusted backend, retention/deletion, backup restore tests, rate limiting, account suspension, PDPA review และ OCR review workflow ก่อนใช้เอกสารจริง
